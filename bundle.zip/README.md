# Contao Matomo Bundle

> [!WARNING]
> not finished, unusable.

## License

This project is licensed under the [Apache 2.0](https://github.com/Web-Ex-Machina/contao-matomo-bundle?tab=Apache-2.0-1-ov-file).
